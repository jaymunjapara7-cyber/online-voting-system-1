namespace OnlineVotingSystem.Models
{
    public class Vote
    {
        public int VoteId { get; set; }
        public int UserId { get; set; }
        public int CandidateId { get; set; }
    }
}