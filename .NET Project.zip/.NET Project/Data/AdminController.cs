using Microsoft.AspNetCore.Mvc;
using OnlineVotingSystem.Data;
using OnlineVotingSystem.Models;

namespace OnlineVotingSystem.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Dashboard()
        {
            return View(_context.Candidates.ToList());
        }

        public IActionResult AddCandidate() => View();

        [HttpPost]
        public IActionResult AddCandidate(Candidate c)
        {
            _context.Candidates.Add(c);
            _context.SaveChanges();
            return RedirectToAction("Dashboard");
        }
    }
}