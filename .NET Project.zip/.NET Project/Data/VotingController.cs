using Microsoft.AspNetCore.Mvc;
using OnlineVotingSystem.Data;
using System.Linq;

namespace OnlineVotingSystem.Controllers
{
    public class VotingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VotingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.Candidates.ToList());
        }

        public IActionResult Vote(int id)
        {
            var userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
                return RedirectToAction("Login", "Account");

            var user = _context.Users.Find(userId);

            if (user.HasVoted)
                return Content("You already voted!");

            var candidate = _context.Candidates.Find(id);
            candidate.Votes++;

            user.HasVoted = true;

            _context.SaveChanges();

            return RedirectToAction("Result");
        }

        public IActionResult Result()
        {
            return View(_context.Candidates.ToList());
        }
    }
}
