using System.ComponentModel.DataAnnotations;

namespace OnlineVotingSystem.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public bool HasVoted { get; set; } = false;
        public bool IsAdmin { get; set; } = false;
    }
}